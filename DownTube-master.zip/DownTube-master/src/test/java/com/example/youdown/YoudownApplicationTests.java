package com.example.youdown;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YoudownApplicationTests {}
