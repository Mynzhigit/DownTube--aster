package com.example.youdown.models.enums;

public enum FileType {
    AUDIO,
    VIDEO
}
