package com.example.youdown.models.enums;

public enum RequestData {
    ALL,
    PLAYLIST,
    CHANNEL
}
