package com.example.youdown;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YoudownApplication {
	public static void main(String[] args) {
		SpringApplication.run(YoudownApplication.class, args);
	}
}
