package com.example.youdown.constants;

public class Constants {
    public final static String directoryPathForMediaPackage = "./media/";
}
