package com.example.youdown.models.enums;

public enum Role {
    ADMIN,
    USER
}
