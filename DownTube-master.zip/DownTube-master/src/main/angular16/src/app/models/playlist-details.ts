export interface PlaylistDetails {
    readonly title: string;
    readonly viewCount: number;
    readonly author: string;
    readonly videoCount: number;
}
