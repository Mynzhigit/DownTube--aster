export interface PlaylistVideoDetails {
    readonly thumbnails: string;
    readonly index: number;
    readonly title: string;
    readonly videoId: string;
}
