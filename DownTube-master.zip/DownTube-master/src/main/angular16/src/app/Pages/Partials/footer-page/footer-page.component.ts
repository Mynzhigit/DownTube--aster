import { Component } from '@angular/core';

@Component({
  selector: 'app-footer-with-other-parts',
  templateUrl: './footer-page.component..html',
  styleUrls: ['./footer-page.component.css']
})
export class FooterWithOtherPartsComponent {

}
