$(document).ready(function () {
    // MAKE SOME MAGIC THINGS
});
